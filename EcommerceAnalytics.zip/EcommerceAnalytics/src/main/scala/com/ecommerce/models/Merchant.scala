package com.ecommerce.models

case class Merchant(
                     merchant_id: String,            // identifiant unique, ex: M00001
                     name: String,                   // nom du marchand
                     category: String,               // ex: Electronics, Books...
                     region: String,                 // région géographique, ex: Nouvelle-Aquitaine
                     //commission_rate: Double,
                    // je rencontre un problème de conversion de String En Double sur commission_rate , essayons un String voir
                     commission_rate: String,       // taux de commission entre 0.0 et 1.0
                     establishment_date: String     // format: yyyyMMdd
                   )

