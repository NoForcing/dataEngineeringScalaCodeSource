package com.ecommerce.models


case class Product(
                    product_id: String,
                    name: String,
                    category: String,
                    price: Double,
                    merchant_id: String,
                    rating: Double,      // entre 0.0 et 5.0
                    stock: Int           // quantité disponible
                  )
