package com.ecommerce.models

case class Transaction(
                        transaction_id: String,       // identifiant unique
                        user_id: String,              // référence à l'utilisateur
                        product_id: String,           // référence au produit
                        merchant_id: String,          // référence au marchand
                        amount: Double,               // montant de la transaction
                        timestamp: String,            // date au format yyyyMMddHHmmss
                        location: String,             // ville ou lieu
                        payment_method: String,       // méthode de paiement : CARD, CASH, etc.
                        category: String              // catégorie du produit : Books, Electronics...
                      )
