package com.ecommerce.models

case class EnrichedTransaction(
                                transaction_id: String,
                                amount: Double,
                                timestamp: String,
                                hour: Int,
                                day_of_week: String,
                                month: String,
                                is_weekend: Int,
                                day_period: String,
                                is_working_hours: Int
                              )


