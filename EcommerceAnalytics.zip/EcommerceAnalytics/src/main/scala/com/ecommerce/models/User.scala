package com.ecommerce.models

// définition **case class**
// Une **case class** en Scala est une classe spéciale conçue pour représenter des structures de données immuables

case class User(
                 user_id: String,
                  //age: Int,
                 // je rencontre un problème avec Int  me faut Long pour BigInt
                 age:Long,
                 annual_income: Double,
                 city: String,
                 customer_segment: String,
                 preferred_categories: Array[String]
               )
