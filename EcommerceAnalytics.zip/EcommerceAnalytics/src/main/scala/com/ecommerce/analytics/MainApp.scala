package com.ecommerce.analytics



import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, desc, lit, sum, to_date, to_timestamp, when}

object MainApp {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("Ecommerce Analytics")
      .master("local[*]")
      .getOrCreate()

    // Pour afficher moins de logs dans la console
    spark.sparkContext.setLogLevel("WARN")

    // Création d'une instance de DataIngestion
    val ingestion = new DataIngestion(spark)

    // Création d'une instance de DataTransformer
    val transformer = new DataTransformer(spark)

    // Création d'une instance de DataTransformation
    val dataTransformation = new DataTransformation(spark)


    /*
    Capturer et afficher les erreurs (fichier introuvable, structure incorrecte, etc.).
    En utilisant des blocs de try-catch
     */
    try {
      val transactionsRaw = ingestion.loadTransactions()
      //Afficher le nombre de lignes lues avant validation.
      println(s"[Transactions] Total rows (raw): ${transactionsRaw.count()}")
      val transactions = DataValidator.validateTransactions(transactionsRaw)
      //Afficher le nombre de lignes valides après validation.
      println(s"[Transactions] Rows after validation: ${transactions.count()}")
      transactions.show(5, truncate = false)

      val enrichedTransactions = transformer.enrichTransactions(transactions)
      println("=== Transactions enrichies avec caractéristiques temporelles ===")
      enrichedTransactions.show(5, truncate = false)


      // afficher le schema
      /*
      enrichedTransactions
        .withColumn("time_features", extractTimeFeaturesUDF(col("timestamp")))
        .select("time_features")
        .printSchema() */


    } catch {
      case e: Exception => println(s"[Transactions] ❌ Erreur: ${e.getMessage}")
    }

    try {
      val usersRaw = ingestion.loadUsers()

      /*
      println(s"Total users chargés : ${usersRaw.count()}")
      usersRaw.show(5,truncate = false) */

      println(s"[Users] Total rows (raw): ${usersRaw.count()}")
      val users = DataValidator.validateUsers(usersRaw)
      println(s"[Users] Rows after validation: ${users.count()}")
      users.show(5, truncate = false)
    } catch {
      case e: Exception => println(s"[Users] ❌ Erreur: ${e.getMessage}")
    }

    try {
      val productsRaw = ingestion.loadProducts()
      println(s"[Products] Total rows (raw): ${productsRaw.count()}")
      val products = DataValidator.validateProducts(productsRaw)
      println(s"[Products] Rows after validation: ${products.count()}")
      products.show(5, truncate = false)
    } catch {
      case e: Exception => println(s"[Products] ❌ Erreur: ${e.getMessage}")
    }

    try {
      val merchantsRaw = ingestion.loadMerchants()
      println(s"[Merchants] Total rows (raw): ${merchantsRaw.count()}")
      val merchants = DataValidator.validateMerchants(merchantsRaw)
      println(s"[Merchants] Rows after validation: ${merchants.count()}")
      merchants.show(5, truncate = false)
    } catch {
      case e: Exception => println(s"[Merchants] ❌ Erreur: ${e.getMessage}")
    }

    try {
      // Étapes préalables : ingestion + validation
      val transactionsRaw = ingestion.loadTransactions()
      println(s"[Transactions] Total rows (raw): ${transactionsRaw.count()}")
      val transactions = DataValidator.validateTransactions(transactionsRaw)
      println(s"[Transactions] Rows after validation: ${transactions.count()}")

      val usersRaw = ingestion.loadUsers()
      val users = DataValidator.validateUsers(usersRaw)

      val productsRaw = ingestion.loadProducts()
      val products = DataValidator.validateProducts(productsRaw)

      val merchantsRaw = ingestion.loadMerchants()
      val merchants = DataValidator.validateMerchants(merchantsRaw)

      // Enrichissement global avec la fonction finale
      val enrichedDF = dataTransformation.enrichTransactionData(transactions, users, products, merchants)

      println("=== Transactions enrichies (avec UDF + fenêtres + groupe d'âge) ===")
      enrichedDF.show(5, truncate = false)
      enrichedDF.printSchema()

      // Ajout de colonnes supplémentaires à *enrichedDF*

      /*val enrichedDFPlus= dataTransformation.enrichWithWindowFeatures(enrichedDF)

      println("=== Transactions enrichies (avec UDF + fenêtres + groupe d'âge + windowsfeatures:7d, is_activate) ===")
      enrichedDFPlus.show(5, truncate = false)*/

      // pour voir les données non Null des colonnes spécifié
      /*enrichedDFPlus
        .filter(
          col("active").isNotNull ||
            col("days_visited_7d").isNotNull ||
            col("is_active_user").isNotNull
        )
        .show(false)*/

      // Toutes ces colonnes  Null apparement

      //enrichedDFPlus.printSchema()


      val userActivity7dDF=dataTransformation.enrichWithWindowFeatures(enrichedDF)

      //userActivity7dDF.show(20,truncate =false )

      //nombre de ligne de userActivity7dDF
      println(s"Nombre de lignes de userActivity7dDF ${userActivity7dDF.count()}")
      //les 20 dernières lignes
      println("les 20 dernières lignes ")
      userActivity7dDF.orderBy(desc("user_id")).show(20, truncate = false)


      val activeUsers = userActivity7dDF
        .filter(col("is_active_user") === 1)

      println("User is_active_user")
      activeUsers.show(20, truncate = false) // j'ai que des données contenant des utilisateurs non actif  et aussi la colonne transaction_date qui contient beaucoup de NUll , peut-etre  que toutes ses lignes

      println("Transaction dataset")
      transactions.show(5)

      val withDate = transactions.withColumn("transaction_date", to_date(to_timestamp(col("timestamp"), "yyyyMMddHHmmss")))
      println("Add ,transaction_date ")
      withDate.show(5)

     /*
      // -------------------------------------------------------------------------------------------------------
      val userDailyActivity = withDate
        // on selectionne que deux colonnes , on aura donc en tout 3 colonnes avec la nouvelle colonne active
        .select("user_id", "transaction_date")
        .distinct() // éviter les doublons sur une même journée, ne garde qu’une seule ligne par utilisateur et par jour.
        // lit(1) , une fonction Spark SQL permettant de fournir une constante(1 ici)
        .withColumn("active", lit(1)) // On ajoute une nouvelle colonne active qui vaut 1, ce qui signifie :
      // "cet utilisateur a été actif ce jour-là"

      println("userDailyActivity  DataFrame")
      userDailyActivity.show(5)

      val window7Days = Window /*On commence à définir une fenêtre de fenêtrage. Cela va nous permettre de calculer des agrégats glissants comme sum, count, avg, etc. */
        .partitionBy("user_id") /*Cela signifie : "pour chaque utilisateur (user_id) individuellement".Chaque utilisateur aura sa propre fenêtre temporelle.*/
        /*
        On trie les transactions par date chronologiquement.

        Il s'agit d’une fenêtre en nombre de lignes (rows) et non en temps réel, mais si tu as 1
        transaction par jour, ça revient au même.

        transaction_date est en général un DateType ou StringType, mais RANGE BETWEEN ne fonctionne pas bien avec ça.

        Donc on le cast (convertit) en Long, c’est-à-dire un nombre représentant le nombre de secondes
        depuis le 01/01/1970 (Unix epoch:convention informatique,le temps est mesuré en secondes écoulées
        depuis cette date).

        Cela permet à Spark de manipuler les dates de façon numérique dans les calculs.

        cast("timestamp") + RANGE BETWEEN provoque souvent une erreur (celle que nous avons rencontée), donc ici on bypasse le problème.

         */
        .orderBy(col("transaction_date").cast("long")) // on évite TIMESTAMP
        // -6 → on regarde jusqu’à 6 lignes (jours) avant la ligne courante.
        //  0 → jusqu’à la ligne courante.
        .rowsBetween(-6, 0) // 7 jours glissants

      /*
      En appliquant une fonction sum("active") sur cette fenêtre, tu peux savoir combien de jours actifs
      un utilisateur a eus sur 7 jours glissants(7 derniers jours).
      */

      val userActivity7d = userDailyActivity // colonne user_id, transaction_date, active, + days_visited_7d,is_active_user
        // compte les jours actifs
        /*On regarde pour chaque utilisateur
          Sur les 7 derniers jours (6 lignes précédentes + ligne actuelle)

          Résultat : DF avec une nouvelle colonne days_visited_7d avec le nombre de jours où l'utilisateur a été actif sur la période.
          */
        .withColumn("days_visited_7d", sum("active").over(window7Days)) // applique la fenêtre définie précédemment
        .withColumn("is_active_user", when(col("days_visited_7d") >= 5, 1).otherwise(0))


      println("userActivity7d Dataframe")
      userActivity7d.show(14)


      // 4. Joindre cette activité au DataFrame d’origine
      val dfWithDate = enrichedDF.withColumn("transaction_date", to_date(to_timestamp(col("timestamp"), "yyyyMMddHHmmss")))

      val finalDF = dfWithDate
        .join(userActivity7d, Seq("user_id", "transaction_date"), "left")
        .drop("transaction_date")

       finalDF.show(25)



      //----------------------------------------------------------------------------------------------------------
     */

      println("--------------------------------------------------------------------------------")
      // Ajout de colonnes supplémentaires à *enrichedDF*

        val enrichedDFPlus= dataTransformation.enrichWithWindowFeatures(enrichedDF)

        println("=== Transactions enrichies (avec UDF + fenêtres + groupe d'âge + windowsfeatures:7d, is_activate) ===")
        enrichedDFPlus.show(5, truncate = false)


    } catch {
      case e: Exception =>
        println(s"[Enrichissement global] ❌ Erreur: ${e.getMessage}")
    }


    spark.stop()
  }
}

