// PARTIE 3 : TRANSFORMATIONS AVANCÉES

//Question 3.1 – UDF extractTimeFeatures

package com.ecommerce.analytics

import java.time.format.DateTimeFormatter
import java.time.{DayOfWeek, LocalDateTime}
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.types._

import org.apache.spark.sql.api.java.UDF1
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema


object TimeFeaturesExtractor {

  /*

   User-Defined Function (fonction définie par l’utilisateur)

   Une UDF est une fonction personnalisée que tu écris toi-même, que Spark ne fournit pas par défaut.
   Elle te permet de transformer ou enrichir des colonnes dans un DataFrame avec tes propres règles,
   surtout quand les fonctions Spark natives ne suffisent pas.


    Exemple concret : extractTimeFeatures

    Tu as une colonne timestamp comme "20230730143015" (format yyyyMMddHHmmss),
    et Spark ne peut pas directement extraire l’heure, le jour ou le mois sous forme lisible.

    Tu écris donc une UDF comme(le code après les commentaires):

    Ensuite, tu l’utilises dans une transformation:
    df.withColumn("features", extractTimeFeaturesUDF(col("timestamp")))



   */


  /*
    Elle peut retourner :

    une valeur simple (String, Int, Double…),

    ou une structure complexe (par exemple un Row avec plusieurs champs comme hour, month, is_weekend, etc.).

    Attention

    Les UDFs sont moins performantes que les fonctions Spark natives car elles ne sont pas optimisées par Catalyst.

    Si possible, toujours préférer les fonctions Spark (year, month, hour, etc.), mais quand c’est impossible
    ou trop complexe, les UDFs sont une bonne solution.
   */


    // Définir le schéma du résultat retourné par l’UDF
    val timeFeaturesSchema: StructType = StructType(Seq(
      StructField("hour", IntegerType),
      StructField("day_of_week", StringType),
      StructField("month", StringType),
      StructField("is_weekend", IntegerType),
      StructField("day_period", StringType),
      StructField("is_working_hours", IntegerType)
    ))

  val extractTimeFeaturesUDF: UserDefinedFunction = udf(
    new UDF1[String, Row] {
      override def call(timestamp: String): Row = {
        try {
          val formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
          val dateTime = LocalDateTime.parse(timestamp, formatter)

          val hour = dateTime.getHour
          val dayOfWeek = dateTime.getDayOfWeek match {
            case DayOfWeek.MONDAY => "Monday"
            case DayOfWeek.TUESDAY => "Tuesday"
            case DayOfWeek.WEDNESDAY => "Wednesday"
            case DayOfWeek.THURSDAY => "Thursday"
            case DayOfWeek.FRIDAY => "Friday"
            case DayOfWeek.SATURDAY => "Saturday"
            case DayOfWeek.SUNDAY => "Sunday"
          }

          val month = dateTime.getMonth.toString.capitalize
          val isWeekend = if (dayOfWeek == "Saturday" || dayOfWeek == "Sunday") 1 else 0

          val dayPeriod = hour match {
            case h if h >= 6 && h < 12 => "Morning"
            case h if h >= 12 && h < 18 => "Afternoon"
            case h if h >= 18 && h < 22 => "Evening"
            case _ => "Night"
          }

          val isWorkingHours = if (hour >= 9 && hour < 17) 1 else 0

          new GenericRowWithSchema(
            Array[Any](hour, dayOfWeek, month, isWeekend, dayPeriod, isWorkingHours),
            timeFeaturesSchema
          )
        } catch {
          case _: Exception =>
            new GenericRowWithSchema(Array.fill(6)(null), timeFeaturesSchema)
        }
      }
    },
    timeFeaturesSchema
  )





}
