package com.ecommerce.analytics

import com.ecommerce.analytics.TimeFeaturesExtractor.extractTimeFeaturesUDF
import org.apache.spark.sql.{ Dataset, SparkSession}
import org.apache.spark.sql.functions._
import com.ecommerce.models.{EnrichedTransaction, Transaction}




class DataTransformer(spark: SparkSession) {

  def enrichTransactions(transactionsDS: Dataset[Transaction]): Dataset[EnrichedTransaction] = {

    /* Créer une  colonne imbriquée(struct: colonne contenant un dictionnaire  avec :

    hour, day_of_week, month, is_weekend, day_period, is_working_hours) time_features

       Cette colonne est le résultat de la UDF extractTimeFeaturesUDF qui prend en paramètre

        la colonne **timestamp**, qui est typiquement une chaîne de caractères de type yyyyMMddHHmmss

     */
    // withColumn() retourne un dataframe
    val enrichedDF = transactionsDS.withColumn(
      "time_features",
      extractTimeFeaturesUDF(col("timestamp"))
      // selectionne les colonne finales
    ).select(
      col("*"), // garde  les colonnes origine tel que  transaction_id ,  amount, timestamp
      // On extrait chaque champ du struct time_features pour les transformer en colonnes à part entière
      //On les renomme directement avec .as(...) pour plus de clarté
      col("time_features.hour").as("hour"),
      col("time_features.day_of_week").as("day_of_week"),
      col("time_features.month").as("month"),
      col("time_features.is_weekend").as("is_weekend"),
      col("time_features.day_period").as("day_period"),
      col("time_features.is_working_hours").as("is_working_hours")
    )

    /*
     on obtiens un Dataset enrichi avec des colonnes en plus comme hour , day_of_week , month , is_weekend day_period, is_working_hours
    */
    import spark.implicits._
    /* pour convertir le dataframe retourné par withColumn() en Dataset[T]
       assurons nous que les noms et les types de colonnes dans enrichedDF(dataframe retourné par withColumn())
       correspondent exactement à ceux de EnrichedTransaction(case class), sinon Spark lèvera
       une erreur de mapping implicite (AnalysisException)
    */
    val enrichedDS: Dataset[EnrichedTransaction] = enrichedDF.as[EnrichedTransaction]
    enrichedDS
  }
}
