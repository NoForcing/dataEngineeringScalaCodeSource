//PARTIE 3 : TRANSFORMATIONS AVANCÉES

// Question 3.2 – Fonction enrichTransactionData


package com.ecommerce.analytics

import org.apache.spark.sql.{Dataset, DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import com.ecommerce.models._
import com.ecommerce.analytics.TimeFeaturesExtractor.extractTimeFeaturesUDF

class DataTransformation(spark: SparkSession) {



  def enrichTransactionData(
                             transactions: Dataset[Transaction],
                             users: Dataset[User],
                             products: Dataset[Product],
                             merchants: Dataset[Merchant]
                           ): DataFrame = {

    //import spark.implicits._

    // Étape 1 : jointures
    val joined = transactions
      .join(users, Seq("user_id"))
      .join(products, Seq("product_id", "merchant_id"))
      .join(merchants, Seq("merchant_id"))

    // Étape 2 : enrichissement temporel avec UDF
    val withTimeFeatures = joined.withColumn("time_features", extractTimeFeaturesUDF(col("timestamp")))
      .select(
        col("*"),
        col("time_features.hour"),
        col("time_features.day_of_week"),
        col("time_features.month"),
        col("time_features.is_weekend"),
        col("time_features.day_period"),
        col("time_features.is_working_hours")
      )

    // Étape 3 : fonctions de fenêtrage
    val userWindow = Window.partitionBy("user_id").orderBy("timestamp")
    val countWindow = Window.partitionBy("user_id")

    val withWindows = withTimeFeatures
      .withColumn("transaction_rank", row_number().over(userWindow))
      .withColumn("total_transactions_by_user", count("*").over(countWindow))

    // Étape 4 : tranche d’âge
    val withAgeGroup = withWindows.withColumn("age_group",
      when(col("age") < 25, "Jeune")
        .when(col("age").between(25, 44), "Adulte")
        .when(col("age").between(45, 64), "Age Moyen")
        .otherwise("Senior")
    )

    withAgeGroup
  }


  // Question 3.3 – Analyse par partition Window


  def enrichWithWindowFeatures(df: DataFrame): DataFrame = {
    //import df.sparkSession.implicits._
    //import org.apache.spark.sql.expressions.Window
    //import org.apache.spark.sql.functions._

    // 1. Extraire uniquement la date (sans l'heure)
    // on cree une  nouvelle colonne  transaction_date à partir de colonne timestamp
    /* to_date() ,C'est une fonction Spark SQL qui convertit un champ de type string
    ou timestamp en un type date au format yyyy-MM-dd. */
    // cette ligne ci-dessous me retournait une colonne  data_transaction avec que des Null
    //val withDate = df.withColumn("transaction_date", to_date(col("timestamp")))

    val withDate = df.withColumn("transaction_date", to_date(to_timestamp(col("timestamp"), "yyyyMMddHHmmss")))
    // 2. Créer une colonne active = 1 (pour compter l'activité quotidienne)
    // Cette partie vise à identifier les jours où chaque utilisateur a été actif
    val userDailyActivity = withDate
      // on selectionne que deux colonnes , on aura donc en tout 3 colonnes avec la nouvelle colonne active
      .select("user_id", "transaction_date")
      .distinct() // éviter les doublons sur une même journée, ne garde qu’une seule ligne par utilisateur et par jour.
      // lit(1) , une fonction Spark SQL permettant de fournir une constante(1 ici)
      .withColumn("active", lit(1)) // On ajoute une nouvelle colonne active qui vaut 1, ce qui signifie :
                                   // "cet utilisateur a été actif ce jour-là"

    // 3. Appliquer une fenêtre glissante de 7 jours par utilisateur

    /*
    Je veux analyser l'activité d'un utilisateur sur une période glissante de 7 jours, par utilisateur,
     ordre chronologique, et en évitant les types de données problématiques comme Timestamp
    */

    val window7Days = Window /*On commence à définir une fenêtre de fenêtrage. Cela va nous permettre de calculer des agrégats glissants comme sum, count, avg, etc. */
      .partitionBy("user_id") /*Cela signifie : "pour chaque utilisateur (user_id) individuellement".Chaque utilisateur aura sa propre fenêtre temporelle.*/
       /*
       On trie les transactions par date chronologiquement.

       Il s'agit d’une fenêtre en nombre de lignes (rows) et non en temps réel, mais si tu as 1
       transaction par jour, ça revient au même.

       transaction_date est en général un DateType ou StringType, mais RANGE BETWEEN ne fonctionne pas bien avec ça.

       Donc on le cast (convertit) en Long, c’est-à-dire un nombre représentant le nombre de secondes
       depuis le 01/01/1970 (Unix epoch:convention informatique,le temps est mesuré en secondes écoulées
       depuis cette date).

       Cela permet à Spark de manipuler les dates de façon numérique dans les calculs.

       cast("timestamp") + RANGE BETWEEN provoque souvent une erreur (celle que nous avons rencontée), donc ici on bypasse le problème.

        */
      .orderBy(col("transaction_date").cast("long")) // on évite TIMESTAMP
      // -6 → on regarde jusqu’à 6 lignes (jours) avant la ligne courante.
      //  0 → jusqu’à la ligne courante.
      .rowsBetween(-6, 0) // 7 jours glissants

    /*
    En appliquant une fonction sum("active") sur cette fenêtre, tu peux savoir combien de jours actifs
    un utilisateur a eus sur 7 jours glissants(7 derniers jours).
    */

    val userActivity7d = userDailyActivity // colonne user_id, transaction_date, active, + days_visited_7d,is_active_user
      // compte les jours actifs
      /*On regarde pour chaque utilisateur
        Sur les 7 derniers jours (6 lignes précédentes + ligne actuelle)

        Résultat : DF avec une nouvelle colonne days_visited_7d avec le nombre de jours où l'utilisateur a été actif sur la période.
        */
      .withColumn("days_visited_7d", sum("active").over(window7Days)) // applique la fenêtre définie précédemment
      .withColumn("is_active_user", when(col("days_visited_7d") >= 5, 1).otherwise(0))

    // 4. Joindre cette activité au DataFrame d’origine


    val dfWithDate = df.withColumn("transaction_date", to_date(to_timestamp(col("timestamp"), "yyyyMMddHHmmss")))

     val finalDF = dfWithDate
       /*
        Seq , liste immuable d'éléments ,Cela représente une liste de deux noms de colonnes que l’on
        utilise pour faire la jointure entre deux DataFrames.

        */
         .join(userActivity7d, Seq("user_id", "transaction_date"), "left")
         .drop("transaction_date")

    finalDF

  }


  /*def enrichWithWindowFeatures(df: DataFrame): DataFrame = {
    //import org.apache.spark.sql.expressions.Window
    //import org.apache.spark.sql.functions._

    // 1. Convertir timestamp en colonne de type Date
    val dfWithDate = df.withColumn("date", to_date(col("timestamp"), "yyyyMMddHHmmss"))

    // 2. Définir la fenêtre glissante de 7 jours par utilisateur
    val window7Days = Window
      .partitionBy("user_id")
      .orderBy(col("date").cast("timestamp"))
      .rowsBetween(-6 * 86400, 0)  // rowsBetween en lieu et place de rangeBetween

    // 3. Montant cumulé (cumulative amount sur 7 jours)
    val dfWithCumulative = dfWithDate.withColumn(
      "cumulative_amount_7d",
      sum("amount").over(window7Days)
    )

     // 4. Nombre de jours distincts avec transaction dans les 7 jours
    val dfWithDays = dfWithCumulative
      .withColumn("unique_day", date_format(col("date"), "yyyy-MM-dd"))
      //  Spark ne supporte pas count(DISTINCT ...) dans les fonctions de fenêtrage (OVER(...)).
      //.withColumn("days_visited", countDistinct("unique_day").over(window7Days))

    // 5. Utilisateur actif (≥ 5 jours de transaction dans les 7 derniers jours)
    val result = dfWithDays.withColumn(
      "is_active_user",
      when(col("days_visited") >= 5, 1).otherwise(0)
    )

    result
  }*/
}
