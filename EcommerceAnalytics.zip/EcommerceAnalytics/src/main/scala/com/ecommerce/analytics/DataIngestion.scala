  package com.ecommerce.analytics

  import org.apache.spark.sql.{Dataset, SparkSession}
  import org.apache.spark.sql.types._
  import com.ecommerce.models.{Transaction, User, Product, Merchant}

  class DataIngestion(spark: SparkSession) {

    import spark.implicits._ // une seule fois ici

    def loadTransactions(): Dataset[Transaction] = {
      val schema = StructType(Seq(
        StructField("transaction_id", StringType, nullable = false),
        StructField("user_id", StringType, nullable = false),
        StructField("product_id", StringType, nullable = false),
        StructField("merchant_id", StringType, nullable = false),
        StructField("amount", DoubleType, nullable = true),
        StructField("timestamp", StringType, nullable = true),
        StructField("location", StringType, nullable = true),
        StructField("payment_method", StringType, nullable = true),
        StructField("category", StringType, nullable = true)
      ))

      spark.read
        .option("header", "true")
        .schema(schema)
        .csv("src/main/resources/data/transactions.csv")
        .as[Transaction]
    }

    def loadUsers(): Dataset[User] = {
      spark.read
        //.option("multiline", "true"), il me retourne un seul utilisateur chargé, pas adapté au format de notre Json
        .json("src/main/resources/data/users.json")
        .as[User]
    }

    def loadProducts(): Dataset[Product] = {
      spark.read
        .parquet("src/main/resources/data/products.parquet")
        .as[Product]
    }

    def loadMerchants(): Dataset[Merchant] = {
      spark.read
        .option("header", "true")
        .csv("src/main/resources/data/merchants.csv")
        .as[Merchant]
    }
  }
