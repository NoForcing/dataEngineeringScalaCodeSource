package com.ecommerce.analytics

import org.apache.spark.sql.Dataset
import com.ecommerce.models._

object DataValidator {

  // Transactions : amount > 0 et timestamp a 14 caractères
  def validateTransactions(ds: Dataset[Transaction]): Dataset[Transaction] = {
    ds.filter(tx => tx.amount > 0 && tx.timestamp.length == 14)
  }

  // Users : age entre 16 et 100, et income > 0
  def validateUsers(ds: Dataset[User]): Dataset[User] = {
    ds.filter(u => u.age >= 16 && u.age <= 100 && u.annual_income > 0)
  }

  // Products : price > 0 et rating entre 1 et 5.
  def validateProducts(ds: Dataset[Product]): Dataset[Product] = {
    ds.filter(p => p.price > 0 && p.rating >= 1 && p.rating <= 5)
  }

  // Merchants : commission_rate entre 0 et 1.
  def validateMerchants(ds: Dataset[Merchant]): Dataset[Merchant] = {
    ds.filter { m =>
      try {
        val rate = m.commission_rate.toDouble
        rate >= 0.0 && rate <= 1.0
      } catch {
        case _: NumberFormatException => false
      }
    }
  }
}
